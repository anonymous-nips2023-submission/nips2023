import torch
from data import get_ihdp, get_ihdp1000
import argparse
import random
import numpy as np
from betty.engine import Engine
from betty.configs import Config, EngineConfig
from betty.problems import ImplicitProblem
from scipy.stats import norm
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd
import os
from mmd import compute_mmd
import torch.nn.init as init
from adam import Adam
from tqdm import tqdm
# set random seed

seed = 1234
random.seed(seed)
np.random.seed(seed)
torch.random.manual_seed(seed)
rng = np.random.RandomState(seed)

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=1234)
parser.add_argument('--train_iters', type=int, default=100)
parser.add_argument('--inner_iters', type=int, default=30)
parser.add_argument('--dim', type=int, default=100)
parser.add_argument('--batch_size', type=int, default=512)
parser.add_argument('--child_lr', type=float, default=1e-3)
parser.add_argument('--parent_lr', type=float, default=1e-3)
parser.add_argument('--lambda_mmd', type=float, default=0.0)
parser.add_argument('--n_exps', type=int, default=1000)
parser.add_argument('--exp_start', type=int, default=0)
parser.add_argument('--exp_end', type=int, default=1000)
parser.add_argument('--n_layers', type=int, default=2)
parser.add_argument('--device', type=str, default='cuda:0')
args = parser.parse_args()
device = args.device

class ConcatNet(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(ConcatNet, self).__init__()
        self.fcs = nn.ModuleList()
        self.fcs.append(nn.Sequential(nn.Linear(dim_in + dim_in, dim_out), nn.ELU()))
        self.fcs.append(nn.Sequential(nn.Linear(dim_out + dim_out, dim_out), nn.ELU()))
        self.fcs.append(nn.Sequential(nn.Linear(dim_out + dim_out, dim_out), nn.ELU()))
        self.fcs.append(nn.Sequential(nn.Linear(dim_out + dim_out, 1)))

        self.phis = nn.ModuleList()
        self.phis.append(nn.Linear(1, dim_in))
        self.phis.append(nn.Linear(1, dim_out))
        self.phis.append(nn.Linear(1, dim_out))
        self.phis.append(nn.Linear(1, dim_out))

    def forward(self, x, taus):
        for i in range(len(self.fcs)):
            tau_rep = self.phis[i](taus)
            x = self.fcs[i](torch.cat([x, tau_rep], 1))
        return (x)


class ChildNet(torch.nn.Module):
    def __init__(self, dim_in=200, dim_out=100, dim_tau=25):
        super().__init__()
        #self.phi = nn.Sequential(nn.Linear(25+dim_tau, dim_in), nn.ELU(),
        #                         nn.Linear(dim_in, dim_in), nn.ELU(),
        #                         nn.Linear(dim_in, dim_in), nn.ELU())
        self.phi = nn.ModuleList()
        self.phi.append(nn.Sequential(nn.Linear(25+dim_tau, dim_in), nn.ELU()))
        self.phi.append(nn.Sequential(nn.Linear(dim_in+dim_in, dim_in), nn.ELU()))
        self.phi.append(nn.Sequential(nn.Linear(dim_in+dim_in, dim_in), nn.ELU()))

        self.phi_tau = nn.ModuleList()
        self.phi_tau.append(nn.Sequential(nn.Linear(1, dim_tau)))
        self.phi_tau.append(nn.Sequential(nn.Linear(1, dim_in)))
        self.phi_tau.append(nn.Sequential(nn.Linear(1, dim_in)))

        self.unshared = nn.ModuleList()
        self.unshared.append(ConcatNet(dim_in, dim_out))
        self.unshared.append(ConcatNet(dim_in, dim_out))


    def forward(self, covariate, treatment, taus, return_reps=False):
        assert len(covariate) == len(taus)
        #reprentations = (self.phi(torch.cat([covariate, rep_tau], dim=1)))
        h = covariate
        for i in range(len(self.phi)):
            rep_tau = self.phi_tau[i](taus)
            h = torch.cat([h, rep_tau], 1)
            h = self.phi[i](h)
        out = []
        for layer in self.unshared:
            out += [layer(h, taus)]
        out = torch.stack(out, dim=1)  # (batch, num_domains, style_dim)
        idx = torch.LongTensor(range(treatment.size(0))).to(covariate.device)
        outs = out[idx, treatment.long().squeeze()]  # (batch, style_dim)

        return outs


class ParentNet(torch.nn.Module):
    def __init__(self) -> None:
        super(ParentNet, self).__init__()

        self.net = nn.ModuleList()
        self.net.append(nn.Sequential(nn.Linear(25+5, 100), nn.ELU(),
                                 nn.Linear(100, 100), nn.ELU(),
                                 nn.Linear(100, 1), nn.Sigmoid(),
                                 ))
        self.net.append(nn.Sequential(nn.Linear(25+5, 100), nn.ELU(),
                                      nn.Linear(100, 100), nn.ELU(),
                                      nn.Linear(100, 1), nn.Sigmoid(),
                                      ))

        self.phis = nn.ModuleList()
        self.phis.append(nn.Sequential(nn.Linear(1, 5), nn.ELU()))
        self.phis.append(nn.Sequential(nn.Linear(1, 5), nn.ELU()))


    def forward(self, covariate, treatment, targets):

        target_reps = []
        for layer in self.phis:
            target_reps += [layer(targets)]
        target_reps = torch.stack(target_reps, 1)
        idx = torch.LongTensor(range(treatment.size(0))).to(covariate.device)
        h = target_reps[idx, treatment.long().squeeze()]  # (batch, style_dim)

        out = []
        for layer in self.net:
            out += [layer(torch.cat([h, covariate], 1))]
        out = torch.stack(out, dim=1)  # (batch, num_domains, style_dim)
        idx = torch.LongTensor(range(treatment.size(0))).to(covariate.device)
        outs = out[idx, treatment.long().squeeze()]  # (batch, style_dim)
        return outs.squeeze()



def pin_ball_loss(eps, tau):
    loss = (eps>=0).float() * tau * eps + (eps<0).float()*(tau-1)*eps
    return loss


def save_model(parent_net, child_net, parent_optim, child_optim, PATH):
    torch.save(
        {
            "parent": parent_net.state_dict(),
            "parent_optimizer": parent_optim.state_dict(),
            "child": child_net.state_dict(),
            "child_optimizer": child_optim.state_dict(),
        },
        PATH)

def load_model(parent_net, child_net, parent_optim, child_optim, PATH):
    print('[*] loading models from %s' % PATH)
    checkpoint = torch.load(PATH)
    parent_net.load_state_dict(checkpoint["parent"])
    parent_optim.load_state_dict(checkpoint["parent_optimizer"])
    child_net.load_state_dict(checkpoint["child"])
    child_optim.load_state_dict(checkpoint["child_optimizer"])

def compute_pehe_on_validation(yf_hat_valid, ycf_hat_valid, dataset_dict):
    mu0 = dataset_dict['mu0_valid'].numpy()
    mu1 = dataset_dict['mu1_valid'].numpy()
    eff = (mu1 - mu0).reshape(-1)
    t = dataset_dict['t_valid'].squeeze().numpy()
    eff_pred = ycf_hat_valid.reshape(-1) - yf_hat_valid.reshape(-1)
    eff_pred[t > 0] = -eff_pred[t > 0]
    pehe = np.sqrt(np.mean(np.square(eff_pred - eff)))
    return pehe


pbar = range(args.exp_start, args.exp_end)
for exp_num in pbar:
    if args.n_exps <= 100:
        dataset_dict = get_ihdp(exp_num, rng)
    else:
        dataset_dict = get_ihdp1000(exp_num, rng)

    print(len(dataset_dict['x_test']), torch.sum(dataset_dict['t_test']))

    result_dir = 'results_ihdp%d/%s' % (args.n_exps,
            'GOODValidation_train%d_inner%d_dim%d_mmd%s_lr%s_%s_bs%d_wd' % (args.train_iters, args.inner_iters,
                                                                args.dim, args.lambda_mmd, args.parent_lr,
                                                                args.child_lr, args.batch_size))
    os.makedirs(result_dir, exist_ok=True)
    PATH = os.path.join(result_dir, '%03d.pth' % exp_num)

    print('[*] Start runing experiments on IHDP %d' % exp_num)

    trainset = torch.utils.data.TensorDataset(dataset_dict['x_train'],dataset_dict['t_train'], dataset_dict['y_f_train'])
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=min(args.batch_size, len(dataset_dict['x_train'])), shuffle=True, drop_last=True)

    class Child(ImplicitProblem):
        def training_step(self, batch):
            covariate, treatment, targets = batch
            tau = self.outer(covariate, treatment, targets)
            # during training, we use all training for every tau
            flat_covariate = covariate.repeat(len(tau), 1)
            flat_treatment = treatment.repeat(len(tau), 1)
            flat_targets = targets.repeat(len(tau), 1)
            flat_taus = tau.repeat_interleave(len(covariate), dim=0).unsqueeze(-1)
            assert len(flat_covariate) == len(flat_taus)
            outs = self.module(flat_covariate, flat_treatment, flat_taus)
            eps = flat_targets - outs
            loss = (pin_ball_loss(eps, flat_taus))
            loss = loss.mean()
            self.num_step += 1
            if self.num_step % 10 == 0:
                print('[%d] loss: %.4f' % (self.num_step, loss.item()))
            return loss

        def configure_train_data_loader(self):
            return trainloader

        def configure_module(self):
            return ChildNet().to(args.device)

        def configure_optimizer(self):
            self.num_step = 0
            self.optimizer = Adam(self.module.parameters(), lr=args.child_lr, weight_decay=5e-4)
            return self.optimizer

    class Parent(ImplicitProblem):
        def training_step(self, batch):
            covariate, treatment, targets = batch
            taus = self.module.forward(covariate, treatment, targets).unsqueeze(-1)
            outs = self.inner(covariate, treatment, taus)
            loss = torch.mean(torch.abs(outs-targets))
            self.loss = loss.item()
            return loss

        def configure_train_data_loader(self):
            self.min_loss = 1e9
            self.min_pehe_valid = 1e9
            return [(dataset_dict['x_test'], dataset_dict['t_test'], dataset_dict['y_f_test'])]

        def configure_module(self):
            return ParentNet().to(args.device)

        def configure_optimizer(self):
            self.optimizer = Adam(self.module.parameters(), lr=args.parent_lr, weight_decay=5e-4)
            self.patience = 0
            return self.optimizer

        @torch.no_grad()
        def predict_validation(self):
            covariate = dataset_dict['x_valid'].to(device)
            treatment = dataset_dict['t_valid'].to(device)
            targets = dataset_dict['y_f_valid'].to(device)
            taus = self.module.forward(covariate, treatment, targets).unsqueeze(-1)
            yf_hat_valid = self.inner(covariate, treatment, taus).detach().cpu().numpy()
            ycf_hat_valid = self.inner(covariate, 1-treatment, taus).detach().cpu().numpy()
            pehe = compute_pehe_on_validation(yf_hat_valid, ycf_hat_valid, dataset_dict)
            return pehe


        def optimizer_step(self, *args, **kwargs):
            if self.is_implemented("custom_optimizer_step"):
                assert (
                    not self._is_default_fp16()
                ), "[!] FP16 training is not supported for custom optimizer step."
                if self.gradient_clipping > 0.0:
                    self.clip_grad()
                self.custom_optimizer_step(*args, **kwargs)
            else:
                if self._is_default_fp16():
                    if self.gradient_clipping > 0.0:
                        self.scaler.unscale_(self.optimizer)
                        self.clip_grad()
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                else:
                    if self.gradient_clipping > 0.0:
                        self.clip_grad()
                    self.optimizer.step()

            cur_pehe_valid = self.predict_validation()
            if cur_pehe_valid<=self.min_pehe_valid:
                print(' ** ', cur_pehe_valid, self.min_pehe_valid)
                self.min_pehe_valid = cur_pehe_valid
                self.min_loss = self.loss
                save_model(self.module, self.inner.module, self.optimizer, self.inner.optimizer, PATH)
                self.patience = 0
            else:
                self.patience += 1
                if self.patience >= 10:
                    for g in self.optimizer.param_groups:
                        cur_parent_lr = g['lr']
                        break
                    for g in self.inner.optimizer.param_groups:
                        cur_child_lr = g['lr']
                        break
                    load_model(self.module, self.inner.module, self.optimizer, self.inner.optimizer, PATH)
                    for g in self.optimizer.param_groups:
                        g['lr'] = cur_parent_lr * 0.1
                    for g in self.inner.optimizer.param_groups:
                        g['lr'] = cur_child_lr * 0.1
                    self.patience = 0
                    print('**** reset lr ', self.optimizer.param_groups[0]['lr'],
                          self.inner.optimizer.aram_groups[0]['lr'], self.min_pehe_valid)


    engine_config = EngineConfig(train_iters=args.train_iters*args.inner_iters, logger_type="none")
    parent_config = Config(log_step=1, first_order=True, retain_graph=True)
    child_config = Config(type="darts", unroll_steps=args.inner_iters)


    parent = Parent(name="outer", config=parent_config, device=args.device)
    child = Child(name="inner", config=child_config, device=args.device)

    problems = [parent, child]
    u2l = {parent: [child]}
    l2u = {child: [parent]}
    dependencies = {"l2u": l2u, "u2l": u2l}

    engine = Engine(config=engine_config, problems=problems, dependencies=dependencies)
    engine.run()

    with torch.no_grad():
        load_model(parent.module, child.module, parent.optimizer, child.optimizer, PATH)

        # out-sample
        covariate = dataset_dict['x_test'].to(device)
        treatment = dataset_dict['t_test'].to(device)
        targets = dataset_dict['y_f_test'].to(device)
        learned_tau = parent.module.forward(covariate, treatment, targets)
        device = args.device
        y_cf = dataset_dict['y_cf_test']
        y_cf_pred = child.module.forward(dataset_dict['x_test'].to(device), 1-dataset_dict['t_test'].to(device), learned_tau.unsqueeze(-1))
        y_f_pred = child.module.forward(dataset_dict['x_test'].to(device), dataset_dict['t_test'].to(device), learned_tau.unsqueeze(-1))

        out = [dataset_dict['mu0'], dataset_dict['mu1'], dataset_dict['t_test'], dataset_dict['y_f_test'], dataset_dict['y_cf_test'], y_f_pred.cpu(), y_cf_pred.cpu()]
        out = torch.cat(out, 1)

        df = pd.DataFrame(out.numpy(), columns=['mu0', 'mu1', 'Treatment', 'y_f', 'y_cf', 'y_f_hat', 'y_cf_hat'])
        fp = '%s/test_exp%03d.csv' % (result_dir, exp_num)
        df.to_csv(fp, index=False)
        print('[*] saved %s' % fp)

        mu0 = dataset_dict['mu0'].numpy().reshape(-1)
        mu1 = dataset_dict['mu1'].numpy().reshape(-1)
        eff = mu1-mu0
        ycf_p = df['y_cf_hat'].to_numpy().reshape(-1)
        yf_p = df['y_f_hat'].to_numpy().reshape(-1)
        t = df['Treatment'].to_numpy().reshape(-1)
        eff_pred = ycf_p - yf_p
        eff_pred[t > 0] = -eff_pred[t > 0]
        ate_pred = np.mean(eff_pred)
        bias_ate = np.abs(ate_pred - np.mean(eff))
        pehe = np.sqrt(np.mean(np.square(eff_pred - eff)))
        print('[*]exp%03d: PEHE: %.4f, ATE: %.4f' % (exp_num, pehe, bias_ate))

        # in-sample
        covariate = dataset_dict['x_train'].to(device)
        treatment = dataset_dict['t_train'].to(device)
        targets = dataset_dict['y_f_train'].to(device)
        learned_tau = parent.module.forward(covariate, treatment, targets)
        device = args.device
        y_cf = dataset_dict['y_cf_train']
        y_cf_pred = child.module.forward(dataset_dict['x_train'].to(device), 1-dataset_dict['t_train'].to(device), learned_tau.unsqueeze(-1))
        y_f_pred = child.module.forward(dataset_dict['x_train'].to(device), dataset_dict['t_train'].to(device), learned_tau.unsqueeze(-1))

        out = [dataset_dict['mu0_train'], dataset_dict['mu1_train'], dataset_dict['t_train'],
               dataset_dict['y_f_train'], dataset_dict['y_cf_train'], y_f_pred.cpu(), y_cf_pred.cpu()]
        out = torch.cat(out, 1)

        df = pd.DataFrame(out.numpy(), columns=['mu0', 'mu1', 'Treatment', 'y_f', 'y_cf', 'y_f_hat', 'y_cf_hat'])
        fp = '%s/train_exp%03d.csv' % (result_dir, exp_num)
        df.to_csv(fp, index=False)
        print('[*] saved %s' % fp)

        mu0 = dataset_dict['mu0_train'].numpy().reshape(-1)
        mu1 = dataset_dict['mu1_train'].numpy().reshape(-1)
        eff = mu1-mu0
        ycf_p = df['y_cf_hat'].to_numpy().reshape(-1)
        yf_p = df['y_f_hat'].to_numpy().reshape(-1)
        t = df['Treatment'].to_numpy().reshape(-1)
        eff_pred = ycf_p - yf_p
        eff_pred[t > 0] = -eff_pred[t > 0]
        ate_pred = np.mean(eff_pred)
        bias_ate = np.abs(ate_pred - np.mean(eff))
        pehe = np.sqrt(np.mean(np.square(eff_pred - eff)))
        print('[*]exp%03d: PEHE: %.4f, ATE: %.4f' % (exp_num, pehe, bias_ate))


