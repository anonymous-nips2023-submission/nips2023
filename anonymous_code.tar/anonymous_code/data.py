import numpy as np
import torch
from copy import deepcopy
import pandas as pd

def get_dissim(device='cpu'):
    
    data_in = np.load('../counterfactual_regression/data/dissimci.train.npz')
    num_samples = len(data_in['x'])
    data = {'x': data_in['x'], 't': data_in['t'], 'yf': data_in['yf'], 'ycf': data_in['ycf']}
    covariate = data['x'].reshape(-1,1)
    treatment = data['t'].reshape(-1,1)
    effect = data_in['yf'].squeeze().astype(np.float32).reshape(-1, 1)
    
    data_in = np.load('../counterfactual_regression/data/dissimci.test.npz')
    data = {'x': data_in['x'], 't': data_in['t'], 'yf': data_in['yf'], 'ycf': data_in['ycf']}
    val_covariate = data['x'].reshape(-1,1)
    val_treatment = data['t'].reshape(-1,1)
    val_effect = data_in['yf'].squeeze().astype(np.float32).reshape(-1, 1)
    val_cf_effect = data_in['ycf'].squeeze().astype(np.float32).reshape(-1, 1)
    
    example = {}
    example['x_train'] = torch.from_numpy(covariate).float()
    example['t_train'] = torch.from_numpy(treatment).float()
    example['y_f_train'] = torch.from_numpy(effect).float()
    example['x_test'] = torch.from_numpy(val_covariate).float()
    example['t_test'] = torch.from_numpy(val_treatment).float()
    example['y_f_test'] = torch.from_numpy(val_effect).float()
    example['y_cf_test'] = torch.from_numpy(val_cf_effect).float()
    return example


def get_cisim(device='cpu'):
    
    data_in = np.load('cisim.train.npz')
    print(dict(data_in).keys(), ' ******')
    num_samples = len(data_in['x'])
    data = {'x': data_in['x'], 't': data_in['t'], 'yf': data_in['yf'], 'ycf': data_in['ycf']}
    covariate = data['x'].reshape(-1,1)
    treatment = data['t'].reshape(-1,1)
    effect = data_in['yf'].squeeze().astype(np.float32).reshape(-1, 1)
    
    data_in = np.load('cisim.test.npz')
    data = {'x': data_in['x'], 't': data_in['t'], 'yf': data_in['yf'], 'ycf': data_in['ycf']}
    val_covariate = data['x'].reshape(-1,1)
    val_treatment = data['t'].reshape(-1,1)
    val_effect = data_in['yf'].squeeze().astype(np.float32).reshape(-1, 1)
    val_cf_effect = data_in['ycf'].squeeze().astype(np.float32).reshape(-1, 1)
    
    example = {}
    example['x_train'] = torch.from_numpy(covariate).float()
    example['t_train'] = torch.from_numpy(treatment).float()
    example['y_f_train'] = torch.from_numpy(effect).float()
    example['x_test'] = torch.from_numpy(val_covariate).float()
    example['t_test'] = torch.from_numpy(val_treatment).float()
    example['y_f_test'] = torch.from_numpy(val_effect).float()
    example['y_cf_test'] = torch.from_numpy(val_cf_effect).float()
    return example


def get_contisim():
    df = pd.read_csv('../simulated_CI2.csv')
    num_intervals = 21
    print(df)

def get_ihdp(exp_num, rng, val_rate=0):
    data_in = dict(np.load('ihdp_npci_1-100.train.npz'))
    example = {}
    I = rng.permutation(range(0, len(data_in['x'])))
    n_valid = int(len(data_in['x'])*val_rate)
    n_train = len(data_in['x']) - n_valid
    I_train = I[:n_train]
    I_valid = I[n_train:]
    
    example['x_train'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num][I_train]
    example['t_train'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1][I_train]
    example['y_f_train'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1][I_train]
    example['y_cf_train'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1][I_train]
    example['mu0_train'] = torch.from_numpy(data_in['mu0']).float()[:,exp_num:exp_num+1][I_train]
    example['mu1_train'] = torch.from_numpy(data_in['mu1']).float()[:,exp_num:exp_num+1][I_train]
    
    example['x_valid'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num][I_valid]
    example['t_valid'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1][I_valid]
    example['y_f_valid'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1][I_valid]
    example['y_cf_valid'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1][I_valid]
    example['mu0_valid'] = torch.from_numpy(data_in['mu0']).float()[:,exp_num:exp_num+1][I_valid]
    example['mu1_valid'] = torch.from_numpy(data_in['mu1']).float()[:,exp_num:exp_num+1][I_valid]
    
    data_in = dict(np.load('ihdp_npci_1-100.test.npz'))
    example['x_test'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num]
    example['t_test'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1]
    example['y_f_test'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1]
    example['y_cf_test'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1]
    example['mu0'] = torch.from_numpy(data_in['mu0']).float()[:,exp_num:exp_num+1]
    example['mu1'] = torch.from_numpy(data_in['mu1']).float()[:,exp_num:exp_num+1]
    
    
    
    return example

def get_ihdp1000(exp_num, rng, val_rate=0.3):
    data_in = dict(np.load('ihdp_npci_1-1000.train.npz'))
    example = {}
    I = rng.permutation(range(0, len(data_in['x'])))
    n_valid = int(len(data_in['x'])*val_rate)
    n_train = len(data_in['x']) - n_valid
    I_train = I[:n_train]
    I_valid = I[n_train:]
    
    example['x_train'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num][I_train]
    example['t_train'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1][I_train]
    example['y_f_train'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1][I_train]
    example['y_cf_train'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1][I_train]
    example['mu0_train'] = torch.from_numpy(data_in['mu0']).float()[:,exp_num:exp_num+1][I_train]
    example['mu1_train'] = torch.from_numpy(data_in['mu1']).float()[:,exp_num:exp_num+1][I_train]
    
    example['x_valid'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num][I_valid]
    example['t_valid'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1][I_valid]
    example['y_f_valid'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1][I_valid]
    example['y_cf_valid'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1][I_valid]
    example['mu0_valid'] = torch.from_numpy(data_in['mu0']).float()[:,exp_num:exp_num+1][I_valid]
    example['mu1_valid'] = torch.from_numpy(data_in['mu1']).float()[:,exp_num:exp_num+1][I_valid]
    
    data_in = dict(np.load('ihdp_npci_1-1000.test.npz'))
    example['x_test'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num]
    example['t_test'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1]
    example['y_f_test'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1]
    example['y_cf_test'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1]
    example['mu0'] = torch.from_numpy(data_in['mu0']).float()[:,exp_num:exp_num+1]
    example['mu1'] = torch.from_numpy(data_in['mu1']).float()[:,exp_num:exp_num+1]
    return example


def get_jobs(exp_num, rng=None):
    data_in = dict(np.load('jobs_DW_bin.train.npz'))
    example = {}
    # we only have 1 split for jobs dataset
    # so we randomly shuffle the training data and report the average results
    rng = np.random.RandomState(exp_num)
    exp_num = 0
    I = rng.permutation(range(0, len(data_in['x'])))
    n_valid = int(len(data_in['x']) * 0.3)
    n_train = len(data_in['x']) - n_valid
    I_train = I[:n_train]
    I_valid = I[n_train:]
    
    example['x_train'] = torch.from_numpy(data_in['x']).float()[:, :, exp_num][I_train]
    example['t_train'] = torch.from_numpy(data_in['t']).float()[:, exp_num:exp_num + 1][I_train]
    example['e_train'] = torch.from_numpy(data_in['e']).float()[:, exp_num:exp_num + 1][I_train]
    example['y_f_train'] = torch.from_numpy(data_in['yf']).float()[:, exp_num:exp_num + 1][I_train]
    
    example['x_valid'] = torch.from_numpy(data_in['x']).float()[:, :, exp_num][I_valid]
    example['t_valid'] = torch.from_numpy(data_in['t']).float()[:, exp_num:exp_num + 1][I_valid]
    example['e_valid'] = torch.from_numpy(data_in['e']).float()[:, exp_num:exp_num + 1][I_valid]
    example['y_f_valid'] = torch.from_numpy(data_in['yf']).float()[:, exp_num:exp_num + 1][I_valid]
    
    data_in = dict(np.load('jobs_DW_bin.test.npz'))
    example['x_test'] = torch.from_numpy(data_in['x']).float()[:, :, exp_num]
    example['t_test'] = torch.from_numpy(data_in['t']).float()[:, exp_num:exp_num + 1]
    example['e_test'] = torch.from_numpy(data_in['e']).float()[:, exp_num:exp_num + 1]
    example['y_f_test'] = torch.from_numpy(data_in['yf']).float()[:, exp_num:exp_num + 1]
    
    print('training: %d samples, valid: %d samples, test: %d samples' %(len(example['y_f_train']),
                                                                        len(example['y_f_valid']), len(example['y_f_test']))),
    return example


def get_twins(exp_num, rng=None):
    data_in = dict(np.load('twins_1-10.train.npz'))
    example = {}
    I = rng.permutation(range(0, len(data_in['x'])))
    n_valid = int(len(data_in['x'])*0.3)
    n_train = len(data_in['x']) - n_valid
    I_train = I[:n_train]
    I_valid = I[n_train:]
    
    example['x_train'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num][I_train]
    example['t_train'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1][I_train]
    example['y_f_train'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1][I_train]
    example['y_cf_train'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1][I_train]
    example['mu0_train'] = example['y_f_train'] * (1 - example['t_train']) + example['y_cf_train'] * example['t_train']
    example['mu1_train'] = example['y_cf_train'] * (1 - example['t_train']) + example['y_f_train'] * example['t_train']
    
    example['x_valid'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num][I_valid]
    example['t_valid'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1][I_valid]
    example['y_f_valid'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1][I_valid]
    example['y_cf_valid'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1][I_valid]
    example['mu0_valid'] = example['y_f_valid'] * (1 - example['t_valid']) + example['y_cf_valid'] * example['t_valid']
    example['mu1_valid'] = example['y_cf_valid'] * (1 - example['t_valid']) + example['y_f_valid'] * example['t_valid']
    
    data_in = dict(np.load('twins_1-10.test.npz'))
    example['x_test'] = torch.from_numpy(data_in['x']).float()[:,:,exp_num]
    example['t_test'] = torch.from_numpy(data_in['t']).float()[:,exp_num:exp_num+1]
    example['y_f_test'] = torch.from_numpy(data_in['yf']).float()[:,exp_num:exp_num+1]
    example['y_cf_test'] = torch.from_numpy(data_in['ycf']).float()[:,exp_num:exp_num+1]
    example['mu0'] = example['y_f_test'] * (1 - example['t_test']) + example['y_cf_test'] * example['t_test']
    example['mu1'] = example['y_cf_test'] * (1 - example['t_test']) + example['y_f_test'] * example['t_test']
    
    #print(len(example['x_train']), torch.sum(example['t_train']), example['y_f_test'], example['y_cf_test'])
    return example



def process_continuous_dataset():
    name = '../simulated_CI2.csv'
    df = pd.read_csv(name)
    npcsv = df.to_numpy()
    npcsv[:,1]/=100.
    train = npcsv[:len(npcsv)//2]
    test = npcsv[len(npcsv)//2:]
    rng = np.random.RandomState(123)
    
    real_trains = []
    real_tests = []
    real_train_cf = []
    real_tests_cf = []
    for i in range(1, 500+1):
        idx = rng.permutation(20)[:1]
        real_trains.append(train[train[:,0]==i][idx][:,1:])
        real_train_cf.append(train[train[:, 0] == i][20-idx][:, 1:])
    for i in range(500+1, 1000+1):
        idx = rng.permutation(20)[:1]
        real_tests.append(test[test[:,0]==i][idx][:,1:])
        real_tests_cf.append(test[test[:, 0] == i][20-idx][:, 1:])
    real_trains = np.concatenate(real_trains, 0)
    real_tests = np.concatenate(real_tests, 0)
    real_trains_cf = np.concatenate(real_train_cf, 0)
    real_tests_cf = np.concatenate(real_tests_cf, 0)
    
    data_train = {'x':real_trains[:,0].reshape(-1,1,1),
                  't':real_trains[:,1].reshape(-1,1),
                  'yf': real_trains[:,2].reshape(-1,1),
                  'ycf':real_trains_cf[:,2].reshape(-1,1)}
    
    data_test = {'x':real_tests[:,0].reshape(-1,1,1),
                 't':real_tests[:,1].reshape(-1,1),
                 'yf':real_tests[:,2].reshape(-1,1),
                 'ycf':real_tests_cf[:,2].reshape(-1,1)}
    
    np.savez('cisim.train.npz', **data_train)
    np.savez('cisim.test.npz', **data_test)

#get_jobs(0, np.random.RandomState())
#process_continuous_dataset()
#for i in range(100):
#get_twins(0, np.random.RandomState(42))

def mixing_function(x, t, e, case=1):
    if case == 1:
        yf = x + t + e
    elif case == 2:
        yf = np.sin(x+2*np.pi*t)+e
    elif case == 3:
        yf = (np.exp(t-x+0.5))*e
    elif case == 4:
        yf = np.exp(np.sin(x+np.pi*t)+e)
    elif case==6:
        yf = generate_nn(x,t,e, n_layer=2, hidden_units=16)
    elif case == 7:
        yf = generate_nn(x, t, e, n_layer=4, hidden_units=16)
    elif case == 8:
        yf = generate_nn(x, t, e, n_layer=8, hidden_units=16)
    elif case == 9:
        yf = generate_nn(x, t, e, n_layer=16, hidden_units=16)
    else:
        yf = np.exp(-5*t+x) + np.exp(t-x+0.5)*e
    
    return yf

@torch.no_grad()
def get_toy(n_samples=10000, case=1, noise='gaussian'):
    example = {}
    start = 0
    end = 1
    if case == 6:
        start = -3
        end = 3
    x = np.random.uniform(0, 1., n_samples)
    t = np.random.uniform(start, end, n_samples)
    if noise == 'gaussian':
        e = np.random.normal(0,1, n_samples)
    else:
        e = np.random.uniform(0,1, n_samples)
    
    
    example['x_train'] = torch.from_numpy(x).float().view(-1,1)
    example['t_train'] = torch.from_numpy(t).float().view(-1,1)
    example['e_train'] = torch.from_numpy(e).float().view(-1,1)
    example['x_test'] = torch.from_numpy(np.array([0.5]).reshape(1,1)).float()
    example['t_test'] = torch.from_numpy(np.array([0.5]).reshape(1,1)).float()
    example['e_test'] = torch.from_numpy(np.array([0.5]).reshape(1,1)).float()
    
    example['x_val'] = example['x_test'].repeat(100, 1)
    example['t_val'] = torch.linspace(start,end,100).view(100, 1)
    example['e_val'] = example['e_test'].repeat(100, 1)
    
    xx = torch.cat([example['x_train'], example['x_test'], example['x_val']], 0)
    tt = torch.cat([example['t_train'], example['t_test'], example['t_val']], 0)
    ee = torch.cat([example['e_train'], example['e_test'], example['e_val']], 0)
    yy = mixing_function(xx,tt,ee,case)
    
    example['yf_train'] = (yy[:len(example['x_train'])]).float().view(-1,1)
    example['y_f_test'] = (yy[len(example['x_train'])]).float().view(1,1)
    example['y_f_val'] = (yy[len(example['x_train'])+1:]).float().view(-1,1)
    assert  len(example['yf_train']) == len(example['x_train'])
    assert  len(example['y_f_test']) == 1
    assert  len(example['y_f_val']) == 100
    return example

import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
def init_weights(net, init_type='normal', init_gain=0.02):
    """Initialize network weights.

    Parameters:
        net (network)   -- network to be initialized
        init_type (str) -- the name of an initialization method: normal | xavier | kaiming | orthogonal
        init_gain (float)    -- scaling factor for normal, xavier and orthogonal.

    We use 'normal' in the original pix2pix and CycleGAN paper. But xavier and kaiming might
    work better for some applications. Feel free to try yourself.
    """
    def init_func(m):  # define the initialization function
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if init_type == 'normal':
                init.normal_(m.weight.data, 0.0, init_gain)
            elif init_type == 'xavier':
                init.xavier_normal_(m.weight.data, gain=init_gain)
            elif init_type == 'kaiming':
                init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                init.orthogonal_(m.weight.data, gain=init_gain)
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
            if hasattr(m, 'bias') and m.bias is not None:
                init.constant_(m.bias.data, 0.0)
        elif classname.find('BatchNorm2d') != -1:  # BatchNorm Layer's weight is not a matrix; only normal distribution applies.
            init.normal_(m.weight.data, 1.0, init_gain)
            init.constant_(m.bias.data, 0.0)

    print('initialize network with %s' % init_type)
    net.apply(init_func)  # apply the initialization function <init_func>


@torch.no_grad()
def generate_nn(x,t,e, n_layer=5, hidden_units=4):
    n_samples = len(x)
    x = x.reshape([n_samples, 1])
    t = t.reshape([n_samples, 1])
    e = e.reshape([n_samples, 1])

    def generate_parameters(treat, covariate, out_dim):
        model = nn.Sequential(nn.Linear(2, 100), nn.LayerNorm(100), nn.ELU(),
                              nn.Linear(100, 100), nn.LayerNorm(100), nn.ELU(),
                              nn.Linear(100, out_dim))
        return model(torch.cat([treat, covariate], 1)).abs()
    
    def run(treat, covariate, noise):
        w = (generate_parameters(treat, covariate, hidden_units).view(n_samples, 1, hidden_units)).abs()
        b = generate_parameters(treat, covariate, 1).view(n_samples, 1, 1)
        out = noise.view(n_samples, 1, 1)
        out = out@w+b
        out = F.logsigmoid(out)
        for _ in range(n_layer-2):
            w = (generate_parameters(treat, covariate, hidden_units**2).view(
                n_samples, hidden_units, hidden_units)).abs()
            b = generate_parameters(treat, covariate, hidden_units).view(n_samples,  1, hidden_units)
            out = out @ w + b
            out = F.logsigmoid(out)/np.sqrt(n_layer)
        w = (generate_parameters(treat, covariate, hidden_units).view(n_samples, hidden_units, 1)).abs()
        b = generate_parameters(treat, covariate, 1).view(n_samples, 1, 1)
        out = out @ w + b
        out = (out)
        return out

    out = run(t,x,e)
    out = (out)
    return out



def create_confounder(n_samples, case, confounder):
    e = np.random.normal(0, 1, n_samples)
    if confounder == 1:
        c = np.random.uniform(0, 1, n_samples)
        x = 2*c - np.random.uniform(0,1, n_samples)
        t = -1*c + 2*np.random.uniform(0,1,n_samples)
        y = mixing_function(x,t,e,case)
    elif confounder == 2:
        c = np.random.uniform(0, 1, n_samples)
        x = c + np.random.uniform(0,1, n_samples)
        t = np.random.uniform(0, 1, n_samples)
        y = mixing_function(x,t,e,case) + c
    elif confounder == 3:
        c = np.random.uniform(0, 1, n_samples)
        t = c + np.random.uniform(0, 1, n_samples)
        x = np.random.uniform(0, 1, n_samples)
        y = mixing_function(x, t, e, case) + c
    return x, t, e, y,c

def get_confounder(n_samples=10000, case=1, confounder=3, noise='gaussian'):
    example = {}
    x,t,e,yf,c = create_confounder(n_samples, case, confounder)
    
    example['x_train'] = torch.from_numpy(x).float().view(-1,1)
    example['t_train'] = torch.from_numpy(t).float().view(-1,1)
    example['yf_train'] = torch.from_numpy(yf).float().view(-1,1)
    
    example['x_test'] = np.array([0.5]).reshape(1,1)
    example['t_test'] = np.array([0.5]).reshape(1,1)
    example['e_test'] = np.array([0.5]).reshape(1,1)
    conf = 0.2
    if confounder == 2:
        example['x_test'] += conf
    elif confounder == 3:
        example['t_test'] += conf
    example['y_f_test'] = mixing_function(example['x_test'], example['t_test'], example['e_test'], case)
    if confounder>=2:
        example['y_f_test'] += conf
    example['x_test'] = torch.from_numpy(example['x_test']).float()
    example['t_test'] = torch.from_numpy(example['t_test']).float()
    example['e_test'] = torch.from_numpy(example['e_test']).float()
    example['y_f_test'] = torch.from_numpy(example['y_f_test']).float()
    
    return example

def mixing_nonidentifiable(x, t, e, case, net=None):
    if case == 1:
        y = x+t+np.sin(np.pi*e)
    #y = x+t+e
    else:
        input = torch.from_numpy(np.concatenate([x,t,e], 1)).float()
        y = net(input).numpy()
    return y

@torch.no_grad()
def get_nonidentifiable(n_samples=10000, case=1, noise='gaussian', ):
    import torch
    import torch.nn as nn
    net = torch.nn.Sequential(nn.Linear(3, 100), nn.ELU(),
                              nn.Linear(100, 100), nn.ELU(),
                              nn.Linear(100, 1))
    x = np.random.uniform(0, 1., n_samples).reshape(-1,1)
    t = np.random.uniform(0, 1., n_samples).reshape(-1,1)
    e = np.random.normal(0, 1, n_samples).reshape(-1,1)
    y = mixing_nonidentifiable(x,t,e,case, net)
    example = {}
    example['x_train'] = torch.from_numpy(x).float().view(-1,1)
    example['t_train'] = torch.from_numpy(t).float().view(-1,1)
    example['yf_train'] = torch.from_numpy(y).float().view(-1,1)
    
    x = np.random.uniform(0, 1., 10)
    t = np.random.uniform(0, 1., 10)
    e = np.random.uniform(-1, 1.0, 10)
    #yf = mixing_nonidentifiable(x,t,e,case, net)
    #ycf = mixing_nonidentifiable(x, 1-t, e, case, net)
    #x = np.array([0.5, 0.5, 0.5, 0.5]).reshape(-1,1)
    #t = np.array([0.5, 0.5, 0.5, 0.5]).reshape(-1,1)
    #e = np.array([-1.0, -0.5, 0.5, 1.0]).reshape(-1,1)
    yf = mixing_nonidentifiable(x,t,e,case, net)
    ycf = mixing_nonidentifiable(x,1-t,e,case,net)
    
    example['x_test'] = torch.from_numpy(x).float().view(-1,1)
    example['t_test'] = torch.from_numpy(t).float().view(-1,1)
    example['y_f_test'] = torch.from_numpy(yf).float().view(-1,1)
    example['y_cf_test'] = torch.from_numpy(ycf).float().view(-1,1)
    return example





